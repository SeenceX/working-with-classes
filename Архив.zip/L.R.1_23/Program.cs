﻿void first()
{
    Console.WriteLine("f");
    int input;
    
    while (true)
    {
        Console.Write("Введите число: ");
        string text = Console.ReadLine();
        if (int.TryParse(text, out int number)) //tryParse возвращает успешно ли выполнено преобразование
        {
            if (number > 0)
            {
                if (text.Length >= 5)
                {
                    Console.WriteLine("Вы ввели число {0}", number);
                    input = number;
                    break;
                }
                Console.WriteLine("В числе меньше 5 разрядов");
                continue;
            }
            Console.WriteLine("Число не положительное");
            continue;
        }
        Console.WriteLine("Не удалось распознать число, попробуйте еще раз.");
    }

    string str = Convert.ToString(input);
    string rStr = string.Empty;
    for (int i = str.Length - 1; i >= 0; i--)
        rStr += str[i];
    
    if (str == rStr)
        Console.WriteLine("Число - палиндром");
    else
        Console.WriteLine("Число - не палиндром");
}
//first();

void second()
{
    int[,] matrix = new int[5, 5];
    Random random = new Random();

    for (int i = 0; i < matrix.GetLength(0); i++)
    {
        for (int j = 0; j < matrix.GetLength(1); j++)
        {
            matrix[i, j] = random.Next(-20, 20);
        }
    }

    for (int i = 0; i < matrix.GetLength(0); i++)
    {
        Console.WriteLine();
        for (int j = 0; j < matrix.GetLength(1); j++)
        {
            Console.Write(matrix[i,j] + " ");
        }
    }
    int max = -100, min = 100;
    int[] indexMax = new int[2];
    int[] indexMin = new int[2];
    

    for (int i = 0; i < matrix.GetLength(0); i++)
   {
       for (int j = 0; j < matrix.GetLength(1); j++)
       {
           if (i < j)
           {
               if (matrix[i, j] > max)
               {
                   max = matrix[i, j];
                   indexMax[0] = i;
                   indexMax[1] = j;
               }
           }
           if (i > j)
           {
               if (matrix[i, j] < min)
               {
                   min = matrix[i, j];
                   indexMin[0] = i;
                   indexMin[1] = j;
               }
           }
       }
   }
    
    matrix[indexMax[0], indexMax[1]] = min;
    matrix[indexMin[0], indexMin[1]] = max;
    Console.WriteLine($"\n\nmax = {max}, min = {min}\nindexMax = {indexMax[0]}|{indexMax[1]}\nindexMin = {indexMin[0]}|{indexMin[1]}\n");
    
    for (int i = 0; i < matrix.GetLength(0); i++)
    {
        Console.WriteLine();
        for (int j = 0; j < matrix.GetLength(1); j++)
        {
            Console.Write(matrix[i,j] + " ");
        }
    }
}
//second();

void third()
{
    List<Persons> list = new List<Persons>();
    list.Add(new Persons("Ivanov", 180));
    list.Add(new Persons("Andreev", 194));
    list.Add(new Persons("Vasilev", 174));
    list.Add(new Persons("Saharov", 168));
    list.Add(new Persons("Levedev", 183));
    list.Add(new Persons("Mihailov", 169));
    Console.WriteLine("Список:");
    list.ForEach(person => Console.
        WriteLine($"{person.getSecondName()} - {person.getHeight()}"));
    
    var avg = 0;
    foreach (var person in list)
    {
        avg += person.getHeight();
    }

    avg /= list.Count;
    Console.WriteLine($"{avg} - {list.Count}");
    Console.WriteLine($"Средний рост равен {avg}\n");
    Console.WriteLine("Удовлетворяют условию по росту");
    foreach (var person in list)
    {
        if (person.getHeight() >= avg)
            Console.WriteLine($"{person.getSecondName()} - {person.getHeight()}");
    }
}
third();

class Persons
{
    private string _secondName;
    private int _height;
    
    public Persons(string secondName, int height)
    {
        _secondName = secondName;
        _height = height;
    }

    public int getHeight()
    {
        return _height;
    }

    public string getSecondName()
    {
        return _secondName;
    }
}

class First
{
    private int _input;
    private string _text;

    public First()
    {
        //
    }
    
}